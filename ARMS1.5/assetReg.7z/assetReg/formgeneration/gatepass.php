<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Gate Pass Form</title>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <h1>Gate Pass Form</h1>
<form class="cf" action="gatepassgen.php" method="post">
  <div class="half left cf">
    
    <input type="text" name="transporterName" id="input-email" placeholder="Name Of Transporter">
	<input type="text" name="company" id="input-name"  placeholder="Company Of Transporter">
    <input type="text" name="destination" id="input-subject" placeholder="Destination Of Goods">
	<input type="text" name="destinationBranch" id="input-subject" placeholder="Destination Branch">
	
   
    
  </div>
  <div class="half right cf">
  <input type="text" name="username" id="input-name"  placeholder="Name Of Receiver">
    <input type="text" name="department" id="input-email" placeholder="Department Of Receiver">
    <textarea name="allocationReason" type="text" id="input-message" placeholder="Purpose Of Movement:"></textarea>
  </div>  
  <input type="submit" value="Submit" id="input-submit">
</form>
  
  

</body>

</html>
