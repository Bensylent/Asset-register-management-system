

<?php
 //$con = mysqli_connect('hostname','username','password','database');
 require "connection.php";
?>


<?php include 'database.php'; ?>
<?php   
    $id=(int)$_GET['n'];
    $query="SELECT * FROM `asset` where serialNumber=".$id;
    $result=$mysqli->query($query) or die($mysqli->error.__LINE__);
    $person=$result->fetch_assoc();
?>

<?php
if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT `model`, `type`, `serialNumber`, `monitorModel`, `monitorSerial`, `computerName`, `currentUser`, `ram`, `hdd`, `processor`, `os`, `supplier`, `dop`, `warranty`, `ipaddress`, `branch`, `company`, `mouse`, `keyboard`, `loggedBy` FROM `asset` WHERE CONCAT(`model`, `type`, `serialNumber`, `monitorModel`, `monitorSerial`, `computerName`, `currentUser`, `ram`, `hdd`, `processor`, `os`, `supplier`, `dop`, `warranty`, `ipaddress`, `branch`, `company`, `mouse`, `keyboard`, `loggedBy`) LIKE '%".$valueToSearch."%' order by dop DESC LIMIT 100";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `asset`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "assetregister");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>ASSET REGISTER MANAGEMENT SYSTEM</title>
  
  
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css'>

      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/stylepopup.css">
      <link rel="stylesheet" href="css/styleform.css">
      <style>
            table tr:not(:first-child){
                cursor: pointer;transition: all .25s ease-in-out;
            }
            table tr:not(:first-child):hover{background-color: #ddd;}
        </style>
	  
	
  
</head>

<body>

  <head>
  <script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
  <script type="text/javascript" src="https://www.google.com/jsapi"></script>
  <script  src="js/index.js"></script>
            <script  src="js/indexpopup.js"></script>
            <script  src="js/indexform.js"></script>
        

  </head>
<nav class="navbar navbar-default">
    <div class="container-fluid">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
       
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li class="active"><a href="home.php">Dashboard</a></li>
          <li><a href="profile.php">My Profile</a></li>
          <li><a href="adminRegistration.php"> Create Accounts</a></li>
          <li><a href="">Settings</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href="profile.php"><?php session_start();  echo $_SESSION['user'];?> </a></li>
          <li><a href="logout.php">Log out</a></li>
        </ul>
      </div>
      <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-fluid -->
  </nav>
  <!--header-->
  <div class="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-10 ">
          <h2>Asset Register Management System</h2>
        </div>
        <div class="col-md-2 ">
        <div class="dropdown create">
          <form action="Search.php" method="post" name="formq" id="formq">
        <tr>
        <td><input style="width:90%; border-radius:3px;margin:5px; color:black;" type="text" name="valueToSearch" placeholder="Search..."></td>
        <td><input class="btn" style="float:right; border-radius: 3px;position: absolute;z-index: 9;cursor: pointer;padding: 5px 20px;background-color: #6DBCDB;border: 1px solid #6DBCDB;color: #ffffff;font-size: 11px;text-transform: uppercase;margin-bottom: 10px;transition: .2s; margin:5px;"  type="submit" name="search" value="Filter"></td>
        </tr>
        </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--Breadcrumb-->
  <!--main section-->
  <section id="main">
    <div class="container">
      <div class="row">
        <div class="col-md-24">
          <div class="panel panel-default animated zoomIn">
            <div class="panel-heading main-color-bg">
              <h3 class="panel-title">View And Edit</h3>
            </div>
            <form action="process.php?n=<?php echo $person['serialNumber']; ?>" method="post">




<table class="form_select" style="width:49%; border-radius:3px;margin:5px;">
                    <tr>
                        <td>Date Of Purchase:</td>
                        <td style="border-radius:3px;margin:5px;"><input type="text" name="dop" class="form-control" value="<?php echo $person['dop']; ?>"></td>
                        <td>Asset Type:</td>
                        <td><input type="text" name="type" class="form-control" value="<?php echo $person['type']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Company:</td>
                        <td><input type="text" name="company" class="form-control" value="<?php echo $person['company']; ?>"></td>
                        <td>Serial Number:</td>
                        <td><input type="text" name="serialNumber" class="form-control" value="<?php echo $person['serialNumber']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Serial Number:</td>
                        <td><input type="text" name="serialNumber" class="form-control" value="<?php echo $person['serialNumber']; ?>"></td>
                        <td>Model:</td>
                        <td><input type="text" name="model" class="form-control" value="<?php echo $person['model']; ?>"></td>
                    </tr>
                    <tr>
                        <td>User Name:</td>
                        <td><input type="text" name="currentUser" class="form-control" value="<?php echo $person['currentUser']; ?>"></td>
                        <td>Computer Name:</td>
                        <td><input type="text" name="computerName" class="form-control" value="<?php echo $person['computerName']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Supplier:</td>
                        <td><input type="text" name="supplier" class="form-control" value="<?php echo $person['supplier']; ?>"></td>
                        <td>Logged By:</td>
                        <td><input type="text" name="loggedBy" class="form-control" value="<?php echo $person['loggedBy']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Monitor Model:</td>
                        <td><input type="text" name="monitorModel" class="form-control" value="<?php echo $person['monitorModel']; ?>"></td>
                        <td>Monitor Serial Number:</td>
                        <td><input type="text" name="monitorSerial" class="form-control" value="<?php echo $person['monitorSerial']; ?>"></td>
                    </tr>                       
                    <tr>
                        <td>Hard Disk Drive:</td>
                        <td><input type="text" name="hdd" class="form-control" value="<?php echo $person['hdd']; ?>"></td>
                        <td>RAM:</td>
                        <td><input type="text" name="ram" class="form-control" value="<?php echo $person['ram']; ?>"></td>
                    </tr>
                    <tr>
                        <td>Operating System:</td>
                        <td><input type="text" name="os" class="form-control" value="<?php echo $person['os']; ?>"></td>
                        <td>Processor:</td>
                        <td><input type="text" name="processor" class="form-control" value="<?php echo $person['processor']; ?>"></td>
                    </tr>
                    <tr>
                        <td>KeyBoard:</td>
                        <td><input type="text" name="keyboard" class="form-control" value="<?php echo $person['keyboard']; ?>"></td>
                        <td>Mouse:</td>
                        <td><input type="text" name="mouse" class="form-control" value="<?php echo $person['mouse']; ?>"></td>
                    </tr>
                    <tr>
                        <td>IP Address:</td>
                        <td><input type="text" name="ipaddress" class="form-control" value="<?php echo $person['ipaddress']; ?>"></td>
                        <td>Location:</td>
                        <td><input type="text" name="branch" class="form-control" value="<?php echo $person['branch']; ?>"></td>
                    </tr>
                    <tr>
                    <td>Status:</td>
                        <td><input type="text" name="" id="" class="form-control" disabled value="<?php echo $person['status']; ?>"></td>
                    </tr>
                </table>
                <button class="btn btn-info" name="edit">Edit</button>
</form>
            </div>
			
          </div>
        </div>
      </div>
  </section>

  <!-- footer -->
  <footer id="footer">
    <p>&copy; Developed by <i><strong>FML GCIT</p>
    </footer>
      </div>
    </div>
  </div>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js'></script>

  

    <script  src="js/index.js"></script>
    <script  src="js/indexpopup.js"></script>
    <script  src="js/indexform.js"></script>




</body>

</html>