<?php

    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'assetregister';
    $mysqli = new mysqli($servername,$username,$password,$dbname) or die($mysqli->error);

 
 if ($_SERVER['REQUEST_METHOD'] == 'POST') 
    {
        if (isset($_POST['laptop'])) {
			
			
            $UserName = $_POST["UserName"];
            $ComputerName = $_POST["ComputerName"];
            $assetType = $_POST["assetType"];
            $supplier = $_POST["supplier"];
            $warranty = $_POST["warranty"];
            $make = $_POST["make"];
            $model = $_POST["model"];
            $os = $_POST["os"];
            $processor = $_POST["processor"];
            $hdd = $_POST["hdd"];
            $ram = $_POST["ram"];
            //$Additional = $_POST["Additional"];
            $branch = $_POST["branch"];
            $dop = $_POST["dop"];
           // $ipaddress = $_POST["ipaddress"];
            //$monitorSerial = $_POST["monitorSerial"];
           // $monitorModel = $_POST["monitorModel"];
            //$keyboard = $_POST["keyboard"];
           // $mouse = $_POST["mouse"];
            $SerialNumber = $_POST["SerialNumber"];
            $department = $_POST["department"];
            $company = $_POST["company"];


            //$assetID = "Garry3465";

            $rand = rand(1,10000);
            $assetID = $SerialNumber . $rand;

			

            $res = $mysqli->query("SELECT * FROM `asset_details` WHERE `serialNumber`= '$SerialNumber'"); // duplicates
            
            if($res->num_rows == 0){
                
	            $sql= "INSERT INTO asset_details (assetID, serialNumber, model,type)
                VALUES ('$assetID','$SerialNumber', '$model', '$assetType');
				
				
				INSERT INTO asset_specs (assetID, ram, hdd,processor,os,)
                VALUES ((SELECT assetID FROM asset_details WHERE serialNumber='$SerialNumber'), '$ram', '$hdd','$processor','$os')";
				
	 
	   
	           
				 
                if ( $mysqli->query($sql)===TRUE){
                header('location:home.php');
                }
                else {
                echo "The enquiry could not be submitted";
                }
            }else{
                echo "Asset Already Exists";
            }
        }
    }

 
 
 
 
 
 
 
 
	

/*

INSERT INTO asset_location (assetID, branch, company,ipaddress,department)
                VALUES ((SELECT assetID FROM asset_details WHERE serialNumber='$SerialNumber'), '$branch', '$company','$ipaddress','$department')";


               
	 
	            INSERT INTO asset_users (assetID, computerName, currentUser)
                VALUES ((SELECT assetID FROM asset_details WHERE serialNumber='$SerialNumber'), '$ComputerName', '$UserName')";


 INSERT INTO asset_specs (assetID, ram, hdd,processor,os,)
                VALUES ((SELECT assetID FROM asset_details WHERE serialNumber='$SerialNumber'), '$ram', '$hdd','$processor','$os')
	 
	            INSERT INTO asset_delivery (assetID, supplier, dop,warranty)
                 VALUES ((SELECT assetID FROM asset_details WHERE serialNumber='$SerialNumber'), '$supplier', '$dop','$warranty')";


if($conn->query($mysql_qry)===TRUE){
	
	echo "Insert Success,Welcome User!";
}else{
	echo "Error:" . $mysql_qry ."<br>" . $conn->error;
}

	$conn->close();


INSERT INTO user (name)
     VALUES ('John Smith');
INSERT INTO user_details (id, weight, height)
     VALUES ((SELECT id FROM user WHERE name='John Smith'), 83, 185);
	 
	 
	 
	 
	 $sql = "INSERT INTO asset (assetID,model,type,serialNumber,monitorModel,monitorSerial,computerName,currentUser,ram,hdd,processor,os,
				supplier,dop,warranty,ipaddress,make,branch,company,mouse,keyboard)
                VALUES ('$assetID','$model','$assetType','$SerialNumber','$monitorModel','$monitorSerial','$ComputerName','$UserName','$ram',
				'$hdd','$processor','$os','$supplier','$dop','$warranty','$ipaddress','$make','$branch','$company','$mouse','$keyboard')";
*/


?>