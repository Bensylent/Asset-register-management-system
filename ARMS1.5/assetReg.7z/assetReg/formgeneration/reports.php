<html>

<head>
<script>
$(function(){
$("#from").datepicker();

});

$(function(){
$("#to").datepicker();

});



</script>
</head>

<body>


<form action="index.php" method="POST">

<input type="text" name="type" placeholder="name"></br></br>
<select name="company">
<option>Company</option>
<option value="FML">FML</option>
<option value="FMHC">FMHC</option>
<option value="FMHL">FMHL</option>
<option value="FMP">FMP</option>
<option value="FMW">FMW</option>
<option value="FMF">FMF</option>
<option value="Tristar">Tristar</option>
<option value="FMRE">FMRE</option>
</select></br></br>

<label>From Date</label></br></br>
<input type="date" name="from" placeholder="name"></br></br>
<label>To Date</label></br></br>
<input type="date" name="to" placeholder="name">



</form>

<?php

$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'assetregister';
$mysqli = new mysqli($servername,$username,$password,$dbname) or die($mysqli->error);

if(isset($_POST[submit])){
	
	        $type = $_POST["type"];
            $from = $_POST["from"];
            $to = $_POST["to"];
			$company = $_POST["company"];
			
			if($type != "" ||$from != "" ||$to != "" ||$company != "" ){
				$query= "Select * from records where type='$type' OR company = '$company' OR 
				dop = '$from' AND dop = '$to' ";
				$data= mysqli_query($mysqli,$query) or die('error');
				if(mysqli_num_rows($data)>0){
					while($row=mysqli_fetch_assoc($data)){
						
						$computerName = $row['computerName'];
						$currentUser = $row['currentUser'];
						$type = $row['type'];
						$model = $row['model'];
						$serialNumber = $row['serialNumber'];
						$hdd = $row['hdd'];
						$ram = $row['ram'];
						$processor = $row['processor'];
						$company = $row['company'];
						$branch = $row['branch'];
					}
					
				}else{
					echo("Record Not Found");
				}
			}
            
}
 
 


?>


</body>
</html>