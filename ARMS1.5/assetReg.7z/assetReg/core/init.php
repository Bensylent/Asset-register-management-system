<?php

session_start();
require 'connection.php';
require 'functions/user.php';
require 'functions/asset.php';

if(logged_in() === true){
    $session_id = $_SESSION['id'];
    $user_data = user_data($conn,$session_id,'id','username','password');


$errors = [];
}

