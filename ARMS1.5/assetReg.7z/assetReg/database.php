<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "assetregister";

    $mysqli = new mysqli($servername, $username, $password, $dbname);
    
    if ($mysqli->connect_error) {
        printf("Connection failed: %s\n" ,$mysqli->connect_error());
    }


?>