<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  
  
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css'>

      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <head>
  <script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
  </head>
<nav class="navbar navbar-default">
    <div class="container-fluid">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
       
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li class="active"><a href="home.php">Home</a></li>
          <li><a href="profile.php">My Profile</a></li>
          <li><a href="newUserRegistration.php">Create Accounts</a></li>
          <li><a href="#">Settings</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href="profile.php"><?php session_start();  echo $_SESSION['user'];?></a></li>
          <li><a href="logout.php">Log out</a></li>
        </ul>
      </div>
      <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-fluid -->
  </nav>
  <!--header-->
  <div class="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-10 ">
          <h2>Asset Register Management System</h2>
        </div>
        <div class="col-md-2 ">
          <div class="dropdown create">
            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Create Content
                <span class="caret"></span>
              </button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
              <li><a type="button" data-toggle="modal" data-target="#addPage">Add page</a></li>
              <li><a href="#">Add post</a></li>
              <li><a href="#">Add user</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

 

  <!--main section-->
  <section id="main">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
         <div class="list-group animated zoomIn">
            <a href="#" class="list-group-item active  main-color-bg">
                  <span class="glyphicon glyphicon-cog"></span> Dashboard
              </a>
            <button class="list-group-item btn open-form"><span class="glyphicon glyphicon-plus-sign"></span> Add Asset</button>
            <a href="formgeneration/comphandovergen.php"><button class="list-group-item "><span class="glyphicon glyphicon-edit"></span> Forms</button></a>
            <button class="list-group-item "><span class="glyphicon glyphicon-wrench"></span> Repairs</button>
            <button class="list-group-item "><span class="glyphicon glyphicon-cog"></span> Service and Maintanance</button>
            <button class="list-group-item "><span class="glyphicon glyphicon-signal"></span> Reports</button>
          </div>
        </div>
        <div class="col-md-9">
          <div class="panel panel-default animated zoomIn">
            <div class="panel-heading main-color-bg">
              <h3 class="panel-title">Forms</h3>
            </div>
            <div class="panel-body">
              <div class="col-md-3">
                <div class="well dash-box">
                  <a href="formgeneration/comphandover.php"><h4><span class="glyphicon glyphicon-blackboard"></span> Handovers</h4></a>
                 
                </div>
              </div>
              <div class="col-md-3 dash-box">
                <div class="well">
                <a href="formgeneration/gatepass.php"><h4><span class=" 	glyphicon glyphicon-road"></span> Gate Pass</h4></a>
                  
                </div>
              </div>
              <div class="col-md-3 dash-box">
                <div class="well">
                  <a href=""><h4><span class="glyphicon glyphicon-edit"></span> Incidents</h4></a>
                 
                </div>
              </div>
              <div class="col-md-3 dash-box">
                <div class="well">
                  <a href=""><h4><span class="glyphicon glyphicon-trash"></span> Disposals</h4></a>
                  
                </div>
              </div>
            </div>
          </div>
         

          </div>
        </div>
      </div>
  </section>

  <!-- footer

<footer id="footer">
    <p>&copy; Developed by <i><strong>Satjeet sandhu</p>
    </footer>



  -->
  




  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>
