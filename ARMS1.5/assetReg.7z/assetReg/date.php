<?php
    $Cur_date = date("Y-m-d");
    $Warranty = intval($row_Recordset1['Hardware_warranty']);
    $timestamp = strtotime($row_Recordset1['Pur_date']);
    $newtimestamp = strtotime("+".$Warranty." years", $timestamp);
    $newtimestamp = date('Y/m/d', $newtimestamp) ;



   if($Cur_date< $newtimestamp)
   {
        $interval = $Cur_date->diff($newtimestamp);
        echo "Valid"."\n\n\n".$interval->y . " years, " . $interval->m." months, ".$interval->d." days "." left";
   }
   else if ($Cur_date > $newtimestamp)
   {
        echo "Expired" ;   
   }
   ?>