

<?php
require ('fpdf17/fpdf.php');

class myPDF extends FPDF{

function header(){
//$this ->Image('logo.jpg',10,6);
$path = 'logo.jpg';
		//$this->SetXY(10,6);
        $this->Image($path,10,2,50);
$this->SetFont('Arial','B',14);
$this->Cell(276,2,'FML GICT Asset Register',0,0,'C');
$this->Ln();
$this->SetFont('Times','',12);
$this->Cell(276,10,'$company',0,0,'C');
$this->Ln(20);

}

function footer(){
$this->SetY(-15);
$this->SetFont('Arial','',8);
$this->Cell(0,10,'Page'.$this->PageNo().'/{nb}',0,0,'C');

}

function headerTable(){
	
	$this->SetFont('Times','B',11);
	$this->Cell(35,7,'Computer Name',1,0,'C');
	$this->Cell(35,7,'User Name',1,0,'C');
	$this->Cell(25,7,'Asset Type',1,0,'C');
	$this->Cell(25,7,'Model',1,0,'C');
	$this->Cell(35,7,'Serial Number',1,0,'C');
	$this->Cell(15,7,'HDD',1,0,'C');
	$this->Cell(15,7,'RAM',1,0,'C');
	$this->Cell(23,7,'Processor',1,0,'C');
	$this->Cell(30,7,'OS',1,0,'C');
	$this->Cell(30,7,'Company',1,0,'C');
	//$this->Cell(30,7,'Branch',1,0,'C');
	$this->Ln();
}
/*
function viewTable($mysqli){
	
	$this->SetFont('Times','',12);
	$this->Cell(20,10,$computerName,1,0,'C');
	$this->Cell(20,10,$currentUser,1,0,'C');
	$this->Cell(20,10,$type,1,0,'C');
	$this->Cell(20,10,$model,1,0,'C');
	$this->Cell(20,10,$serialNumber,1,0,'C');
	$this->Cell(20,10,$hdd,1,0,'C');
	$this->Cell(20,10,$ram,1,0,'C');
	$this->Cell(20,10,$processor,1,0,'C');
	$this->Cell(20,10,$processor,1,0,'C');
	$this->Cell(20,10,$company,1,0,'C');
	$this->Cell(20,10,$branch,1,0,'C');
	
	
}
*/
}

$PDF = NEW MYpdf();
$PDF ->AliasNbPages();
$PDF->AddPage('L','A4',0);
$PDF->headerTable();
//$PDF->viewTable($mysqli);
//ob_end_clean();
$PDF->output();



?>