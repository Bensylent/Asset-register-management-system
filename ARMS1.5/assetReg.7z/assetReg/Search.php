

<?php  

include 'database.php';
      include 'process.php';

    $serialNumber=$_GET['serialNumber'];
    $query="SELECT * FROM `asset`";
    $result=$mysqli->query($query) or die($mysqli->error.__LINE__);
    $today=date("Y/m/d");
    $newToday=strtotime($today);
    while($row=$result->fetch_assoc()){
        
        $newPayback=strtotime($row['warranty']);
        //die(''.$newToday.'<br>'.$newPayback);
        if($newToday>$newPayback){
            $status='OFF Warranty';
        }else if($newToday<=$newPayback){
            $status='ON Warranty';
        }
    
        $query="UPDATE `asset` set `status`='$status' where serialNumber='$serialNumber'";
        $insert_row=$mysqli->query($query) or die($mysqli->error.__LINE__);
    
            if($insert_row){
                continue;
            }else{
                echo "error";
            }
    }


    $query="SELECT * FROM `asset`";
    $result=$mysqli->query($query) or die($mysqli->error.__LINE__);
?>


<?php
if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT `model`, `type`, `serialNumber`, `monitorModel`, `monitorSerial`, `computerName`, `currentUser`, `ram`, `hdd`, `processor`, `os`, `supplier`, `dop`, `warranty`, `ipaddress`, `branch`, `company`, `mouse`, `keyboard`, `loggedBy` FROM `asset` WHERE CONCAT(`model`, `type`, `serialNumber`, `monitorModel`, `monitorSerial`, `computerName`, `currentUser`, `ram`, `hdd`, `processor`, `os`, `supplier`, `dop`, `warranty`, `ipaddress`, `branch`, `company`, `mouse`, `keyboard`, `loggedBy`) LIKE '%".$valueToSearch."%' order by dop DESC LIMIT 100";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `asset`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "assetregister");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>ASSET REGISTER MANAGEMENT SYSTEM</title>
  
  
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css'>

      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/stylepopup.css">
      <link rel="stylesheet" href="css/styleform.css">
      <style>
            table tr:not(:first-child){
                cursor: pointer;transition: all .25s ease-in-out;
            }
            table tr:not(:first-child):hover{background-color: #ddd;}
        </style>
	  
	
  
</head>

<body>

  <head>
  <script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
  <script type="text/javascript" src="https://www.google.com/jsapi"></script>
  <script  src="js/index.js"></script>
            <script  src="js/indexpopup.js"></script>
            <script  src="js/indexform.js"></script>
        

  </head>
<nav class="navbar navbar-default">
    <div class="container-fluid">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
       
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li class="active"><a href="home.php">Dashboard</a></li>
          <li><a href="profile.php">My Profile</a></li>
          <li><a href="adminRegistration.php"> Create Accounts</a></li>
          <li><a href="">Settings</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href="profile.php"><?php session_start();  echo $_SESSION['user'];?> </a></li>
          <li><a href="logout.php">Log out</a></li>
        </ul>
      </div>
      <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-fluid -->
  </nav>
  <!--header-->
  <div class="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-10 ">
          <h2>Asset Register Management System</h2>
        </div>
        <div class="col-md-2 ">
        <div class="dropdown create">
          <form action="Search.php" method="post" name="formq" id="formq">
        <tr>
        <td><input style="width:90%; border-radius:3px;margin:5px; color:black;" type="text" name="valueToSearch" placeholder="Search..."></td>
        <td><input class="btn" style="float:right; border-radius: 3px;position: absolute;z-index: 9;cursor: pointer;padding: 5px 20px;background-color: #6DBCDB;border: 1px solid #6DBCDB;color: #ffffff;font-size: 11px;text-transform: uppercase;margin-bottom: 10px;transition: .2s; margin:5px;"  type="submit" name="search" value="Filter"></td>
        </tr>
        </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--Breadcrumb-->
  <!--main section-->
  <section id="main">
    <div class="container">
      <div class="row">
        <div class="col-md-24">
          <div class="panel panel-default animated zoomIn">
            <div class="panel-heading main-color-bg">
              <h3 class="panel-title">Search And Filter</h3>
            </div>
            <form action="Search.php" method="post" name="formq" id="formq">
            <table id="TableClick" style="text-align:center;" class="list-group-item">
                <tr style="text-align:center;">
                <th>Date Of Purchase</th>
                <th>Type</th>
                  <th>Model</th>
                  <th>Serial Number</th>
                  <th>Company</th>
                  <th>Supplier</th>
                  <th>Branch</th>
                  <th>Logged By</th>
                <!--     <tbody style="display:none">-->
                <th style="display:none">Monitor Model</th>
                <th style="display:none">Monitor Serial Number</th>
                  <th style="display:none">Computer Name</th>
                  <th style="display:none">User Name</th>
                  <th style="display:none">RAM</th>
                  <th style="display:none">HDD</th>
                  <th style="display:none"> Processor</th>
                <th style="display:none">Operating System</th>
                  <th style="display:none">Warranty</th>
                  <th style="display:none">IP Address</th>
                  <th style="display:none">Mouse</th>
                  <th style="display:none">KeyBoard</th>
                  
          </tbody>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr style="text-align:center;">
                    <td><a href="edit.php?n=<?php echo $row['serialNumber']; ?>"><?php echo $row['dop'];?></a></td>
                    <td><?php echo $row['type'];?></td>
                    <td><?php echo $row['model'];?></td>
                    <td><?php echo $row['serialNumber'];?></td>
                    <td><?php echo $row['company'];?></td>
                    <td><?php echo $row['supplier'];?></td>
                    <td><?php echo $row['branch'];?></td>
                    <td><?php echo $row['loggedBy'];?></td>
                <!--     <tbody style="display:none">-->
                    <td style="display:none"><?php echo $row['monitorModel'];?></td>
                    <td style="display:none"><?php echo $row['monitorSerial'];?></td>
                    <td style="display:none"><?php echo $row['computerName'];?></td>
                    <td style="display:none"><?php echo $row['currentUser'];?></td>
                    <td style="display:none"><?php echo $row['ram'];?></td>
                    <td style="display:none"><?php echo $row['hdd'];?></td>
                    <td style="display:none"><?php echo $row['processor'];?></td>
                    <td style="display:none"><?php echo $row['os'];?></td>
                    <td style="display:none"><?php echo $row['warranty'];?></td>
                    <td style="display:none"><?php echo $row['ipaddress'];?></td>
                    <td style="display:none"><?php echo $row['mouse'];?></td>
                    <td style="display:none"><?php echo $row['keyboard'];?></td>
                    
          </tbody>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
  
            </div>
			
          </div>
        </div>
      </div>
  </section>

  <!-- footer -->
  <footer id="footer">
    <p>&copy; Developed by <i><strong>FML GCIT</p>
    </footer>
      </div>
    </div>
  </div>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js'></script>

  

    <script  src="js/index.js"></script>
    <script  src="js/indexpopup.js"></script>
    <script  src="js/indexform.js"></script>




</body>

</html>
