<?php


    $host= 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'users';


    $con = mysqli_connect($host,$username,$password,$dbname) or die(mysqli_connect_error());

?>

