<?php 
require "core/init.php";


if(logged_in() === FALSE){

    session_destroy();
    header('Location:index.php');
    exit();

} else {  ?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  
  
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css'>

      <link rel="stylesheet" href="css/style.css">
	 <!--  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css"> -->
 
  
  <!--    -->

   <link rel="stylesheet" href="css/settingsForm.css"> 
</head>

<body>

  <head>
  <script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
  </head>
<nav class="navbar navbar-default">
    <div class="container-fluid">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
       
      </div>
	  
	  
	  
	   <?php


        if(empty($_POST['update'])===false) {

            $reuired_fields = array('username', 'password');
            foreach ($_POST as $key => $value) {
                if (empty($value) && in_array($key, $reuired_fields) === true) {
                    $errors[]='Fields marked with asterisk are required';
                    break 1;
                }
            }
        }
        ?>
	  

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li class="active"><a href="#">Dashboard</a></li>
          <li><a href="#">My Profile</a></li>
          <li><a href="#">Accounts</a></li>
          <li><a href="#">Users</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href=# ""><?php echo $_SESSION['user']; ?></a></li>
          <li><a href="logout.php">Log out</a></li>
        </ul>
      </div>
      <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-fluid -->
  </nav>
  <!--header-->
  <div class="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-10 ">
          <h2>Asset Register Management System</h2>
        </div>
        <div class="col-md-2 ">
          <div class="dropdown create">
            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Create Content
                <span class="caret"></span>
              </button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
              <li><a type="button" data-toggle="modal" data-target="#addPage">Add page</a></li>
              <li><a href="#">Add post</a></li>
              <li><a href="#">Add user</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

 

  <!--main section-->
  <section id="main">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
         <div class="list-group animated zoomIn">
		 
		
            <a href="home.php" class="list-group-item active  main-color-bg">
                  <span class="glyphicon glyphicon-cog"></span> Dashboard
              </a>
			  
			   <!--
            <button class="list-group-item btn open-form"><span class="glyphicon glyphicon-plus-sign"></span> Add Asset</button>
            <a href="formgeneration/comphandovergen.php"><button class="list-group-item "><span class="glyphicon glyphicon-edit"></span> Forms</button></a>
            <button class="list-group-item "><span class="glyphicon glyphicon-wrench"></span> Repairs</button>
            <button class="list-group-item "><span class="glyphicon glyphicon-cog"></span> Service and Maintanance</button>
            <button class="list-group-item "><span class="glyphicon glyphicon-signal"></span> Reports</button>
			
			-->
			
          </div>
        </div>
		
		
		  <?php


            if (isset($_GET['success']) && empty($_GET['success'])) {
                echo '<center> updated successfully!!!! </center><br>';
                echo '<center><a href="logout.php">Log Again</a></center>';
            }else {

        if (empty($_POST['update']) === false and empty($errors)===true) {

                $update_user = array(

                    'username'=> $_POST['username'],
                    
                    'password'=> $_POST['password']

                );


            $id = $user_data['id'];
            update_profile($conn,$update_user,$id);
            header('Location:settings.php?success');
            exit();


            }else if(empty($errors)===false){

                echo '<center>'.output_errors($errors).'</center>';

            }


            ?>

		
		
		
		
		
        <div class="col-md-9">
          <div class="panel panel-default animated zoomIn">
            <div class="panel-heading main-color-bg">
              <h3 class="panel-title">My Profile</h3>
            </div>
            
          </div>
		  
		  
		  
		 
		  
		  
		  
          <form class="cf" action="" method="post" style="text-align: center;">

		  <div class="half left cf">
                
                <input id="text_input" type="text" name="username" placeholder="Username"> <br><br>

            </div> 

            <div class="half right cf">			
                
                <input id="text_input" type="password" name="password" placeholder="Password"><br><br>
            </div>
                <input type="submit" name="update" value="Update" id="input-submit"> 
			
            </form>


          </div>
        </div>
      </div>
  </section>
<?php } ?>
  <!-- footer

<footer id="footer">
    <p>&copy; Developed by <i><strong>Satjeet sandhu</p>
    </footer>



  -->
  




  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>
<?php }?>