<?php $today=getDate(); ?>
<?php
 //$con = mysqli_connect('hostname','username','password','database');
 require "connection.php";
?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>ASSET REGISTER MANAGEMENT SYSTEM</title>
  
  
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css'>

      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/stylepopup.css">
      <link rel="stylesheet" href="css/styleform.css">

      <style>
        label:after {
            content: "Date of Purchase";
            color: gray;
        }
    </STYLE>
	  
	
  
</head>

<body>

  <head>
  <script src="https://cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
  <script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script>

$(function() {
    $(".forms").hide();
    $("#myselect").change(function() {
        switch($(this).val()){ 
            case "0":
                $(".forms").hide().parent().find("#AssetType").show();
                break;
            case "Model 1":
                $(".forms").hide().parent().find("#Laptop").show();
                break;
            case "Model 2":
                $(".forms").hide().parent().find("#Desktop").show();
                break;
			case "Model 3":
                $(".forms").hide().parent().find("#Printer").show();
                break;
            case "Model 4":
                $(".forms").hide().parent().find("#Server").show();
                break;
            case "Model 5":
                $(".forms").hide().parent().find("#Ipad").show();
                break;
			case "Model 6":
                $(".forms").hide().parent().find("#Router").show();
                break;
            case "Model 7":
                $(".forms").hide().parent().find("#Switch").show();
                break;
			case "Model 8":
                $(".forms").hide().parent().find("#Projector").show();
                break;
        }
    });
});



google.load("visualization", "1", {packages:["corechart"]});
 google.setOnLoadCallback(drawChart);
 function drawChart() {

 var data = google.visualization.arrayToDataTable([
 ['Browser', 'Visits'],
 <?php 
 
 $query = "SELECT count(assetID) AS count, type FROM asset GROUP BY type";

 $exec = mysqli_query($conn,$query);
 while($row = mysqli_fetch_array($exec)){

 echo "['".$row['type']."',".$row['count']."],";
 }
 ?>
 ]);

 var options = {
 title: 'Number Of Assets'
 //,is3D:true 
 ,pieHole: 0.4
 };

 var chart = new google.visualization.PieChart(document.getElementById('piechart'));

 chart.draw(data, options);
 }


 google.load("visualization", "1", {packages:["corechart"]});
 google.setOnLoadCallback(drawChart);
 function drawChart() {

 var data = google.visualization.arrayToDataTable([
 ['Browser', 'Visits'],
 <?php 
 
 $query = "SELECT count(assetID) AS count, type FROM asset GROUP BY type";

 $exec = mysqli_query($conn,$query);
 while($row = mysqli_fetch_array($exec)){

 echo "['".$row['type']."',".$row['count']."],";
 }
 ?>
 ]);

 var options = {
 title: 'Number Of Assets'
 //,is3D:true 
 ,pieHole: 0.4
 };

 var chart = new google.visualization.PieChart(document.getElementById('piechart1'));

 chart.draw(data, options);
 }




</script>
  </head>
<nav class="navbar navbar-default">
    <div class="container-fluid">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
       
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li class="active"><a href="home.php">Home</a></li>
          <li><a href="profile.php">My Profile</a></li>
          <li><a href="newUserRegistration.php"> Create Accounts</a></li>
          <li><a href="">Settings</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href="profile.php"><?php session_start();  echo $_SESSION['user'];?> </a></li>
          <li><a href="logout.php">Log out</a></li>
        </ul>
      </div>
      <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-fluid -->
  </nav>
  <!--header-->
  <div class="page-header">
    <div class="container">
      <div class="row">
        <div class="col-md-10 ">
          <h2>Asset Register Management System</h2>
        </div>
        <div class="col-md-2 ">
          <div class="dropdown create">
          <form action="Search.php" method="post" name="formq" id="formq">
        <tr>
        <td><input style="width:90%; border-radius:3px;margin:5px; color:black;" type="text" name="valueToSearch" placeholder="Search..."></td>
        <td><input class="btn" style="float:right; border-radius: 3px;position: absolute;z-index: 9;cursor: pointer;padding: 5px 20px;background-color: #6DBCDB;border: 1px solid #6DBCDB;color: #ffffff;font-size: 11px;text-transform: uppercase;margin-bottom: 10px;transition: .2s; margin:5px;"  type="submit" name="search" value="Filter"></td>
        </tr>
        </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--Breadcrumb-->
 

  <!--main section-->
  <section id="main">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <div class="list-group animated zoomIn">
            <a href="#" class="list-group-item active  main-color-bg">
                  <span class="glyphicon glyphicon-cog"></span> Dashboard
              </a>
            <button class="list-group-item btn open-form"><span class="glyphicon glyphicon-plus-sign"></span> Add Asset</button>
            <a href="forms.php"><button class="list-group-item "><span class="glyphicon glyphicon-edit"></span> Forms</button></a>
            <button class="list-group-item "><span class="glyphicon glyphicon-wrench"></span> Repairs</button>
            <button class="list-group-item "><span class="glyphicon glyphicon-cog"></span> Service and Maintanance</button>
            <button class="list-group-item "><span class="glyphicon glyphicon-signal"></span> Reports</button>
          </div>


          <div class="form-popup">
            <div class="container form-wrapper">
              <button class="btn close-form">Close</button>
              
              <select class="form__select" name="assetType" id="myselect" style="width:49%; border-radius:3px;margin:5px;">
                                      <option value="0">Asset Type</option>
                                      <option value="Model 1">Laptop</option>
                                      <option value="Model 2">Desktop</option>
                                      <option value="Model 3">Printer</option>
                                      <option value="Model 4">Server</option>
                                      <option value="Model 5">Ipad / Tablets</option>
                                      <option value="Model 6">Router</option>
                                      <option value="Model 7">Switch</option>
                                      <option value="Model 8">Projector</option>

                                    </select>
                                    <div id="AssetType" class="forms"></div>
                                    <div id="Laptop" class="forms">
                                    <form action="add.php" method="POST" class="form">
                <table>
                        <tr>
                        <td>
                                      <select class="form__select" name="supplier" id="select" style="border-radius:3px;"  >
                                        <option value="">Supplier</option>
                                        <option value="Nashua">Nashua</option>
                                        <option value="Omni Africa">Omni Africa</option>
                                        <option value="Global Horizons">Global Horizons</option>
                                      </select>
                                    </td>
                                <td>
                                  <input type="date" name= "warranty" value="Date" class="form__select">

                                </td>
                              </tr>
                              <tr>
                                    <td>
                                      <input class="form__select" type="text" name="UserName" placeholder="User Name">
                                    </td>
                                    <td>
                                      <input class="form__select" type="text" name="ComputerName" placeholder="Computer Name">
                                    </td>
                                  </tr>
                                  <tr>
                                        <td>
                                            <select class="form__select" name="make" id="selecta"  >
                                                <option value="">Make</option>
                                                <option value="HP">HP</option>
                                                <option value="LENOVO">Lenovo</option>
                                                <option value="DELL">DEll</option>
                                              </select>
                                        </td>
                                        <td>
                                            <select class="form__select" name="model" id="selectb"  >
                                                <option value="">Model</option>
                                                <option value="HP 450 G1">HP 450 G1</option>
                                                <option value="HP 450 G2">HP 450 G2</option>
                                                <option value="HP 850">HP 850 G1</option>
                                                <option value="HP 850">HP 850 G2</option>
                                                <option value="a">Select HP Model</option>
                                                <option value="LENOVO">LENOVO</option>
                                                <option value="b">Select LENOVO Model</option>
                                                <option value="DELL LATITUDE 5591">DELL LATTITUDE 5591</option>
                                                <option value="DELL LATITUDE 5590">DELL LATTITUDE 5590</option>
                                                <option value="c">Select DELL Model</option>
                                              </select>
                                        </td>
                                     </tr>
                                     <tr>
                                            <td>
                                              <select class="form__select" name="os" id="select"  >
                                                  <option value="">Operating System</option>
                                                  <option value="WIN 10">Windows 10</option>
                                                  <option value="WIN 8">Windows 8</option>
                                                  <option value="WIN 7">Windows 7</option>
                                                </select>
                                          </td>
                                          <td>
                                            <select class="form__select" name="processor" id="select"  >
                                                <option value="">Processor</option>
                                                <option value="CORE I7">core i7 </option>
                                                <option value="CORE I5">core i5</option>
                                                <option value="CORE I3">core i3</option>
                                              </select>
                                        </td>
                                          </tr>
                                          <tr>
                                            <td>
                                              <select class="form__select" name="hdd" id="select"  >
                                                  <option value="">Hard Drive</option>
                                                  <option value="1TB">1TB</option>
                                                  <option value="500GB">500GB</option>
                                                  <option value="300GB">300GB</option>
                                                </select>
                                          </td>
                                          <td>
                                            <select class="form__select" name="ram" id="select"  >
                                                <option value="">RAM</option>
                                                <option value="2GB">2GB</option>
                                                <option value="3GB">3GB</option>
                                                <option value="4GB">4GB</option>
                                                <option value="8GB">8GB</option>
                                                <option value="12GB">12GB</option>
                                                <option value="16GB">16GB</option>
                                              </select>
                                        </td>
                                          </tr>
                </table>
                <table >
                      <tr>
                          <td style="width:10%;">
                              <select class="form__select" name="company" id="select1"  >
                                  <option value="">Company</option>
                                  <option value="FML">First Mutual Life</option>
                                  <option value="FMHC">First Mutual Health</option>
                                  <option value="FMH">First Mutual Holdings</option>
                                  <option value="FMP">First Mutual Properties</option>
                                  <option value="FMW">First Mutual Wealth</option>
                                  <option value="FMRE">First Mutual Reinsurance</option>
                                  <option value="TRISTAR">Tristar Insurance</option>
                                  <option value="FMFUNERAL">First Mutual Funeral</option>
                                </select>
                          </td>
                        
                          <td>
                              <select class="form__select" name="department" id="select2" >
                                  <option value="">Select Department</option>
                                  <option value="FML">Finance</option>
                                  <option value="FML">Individual Business</option>
                                  <option value="FML">Employment Benefit</option>
                                  <option value="FML">Human Resourse</option>
                                  <option value="FML">Information Technology</option>
                                  <option value="FML">Audit</option>
                                  <option value="FML">Admin</option>
                                  <option value="FML">Marketing</option>
                                  <option value="FML">Call Center</option>
                                  <option value="FML">Select Department</option>
                                  <option value="FMHC">Marketing</option>
                                  <option value="FMHC">Finance</option>
                                  <option value="FMHC">Marketing</option>
                                  <option value="FMHC">Select Department</option>
                                  <option value="FMH">Procurement</option>
                                  <option value="FMH">Finance</option>
                                  <option value="FMH">Select Department</option>
                                  <option value="FMP">Finance</option>
                                  <option value="FMP">Properties</option>
                                  <option value="FMP">Select Department</option>
                                  <option value="FMW">Front Office</option>
                                  <option value="FMW">Back Office</option>
                                  <option value="FMW">Finance</option>
                                  <option value="FMW">Select Department</option>
                                  <option value="FMRE">Finance</option>
                                  <option value="FMRE">Finance</option>
                                  <option value="FMRE">Select Department</option>
                                  <option value="TRISTAR">Finance</option>
                                  <option value="TRISTAR">Finance</option>
                                  <option value="TRISTAR">Finance</option>
                                  <option value="TRISTAR">Select Department</option>
                                  <option value="FMFUNERAL">Finance</option>
                                  <option value="FMFUNERAL">Operations</option>
                                  <option value="FMFUNERAL">Sales</option>
                                  <option value="FMFUNERAL">Select Department</option>
              
                                </select>
                          </td>
                      </tr>
                      <tr>
                      <td>
                              <select class="form__select" name="branch" id="select1" >
                                  <option value="0">Branch</option>
                                  <option value="HEAD OFFICE">Head Office</option>
                                  <option value="99 JASON MOYO">99 Jason Moyo</option>
                                  <option value="MSASA">Msasa Branch</option>
                                  <option value="BRYNESTONE">Brynestone House</option>
                                  <option value="KADOMA">Kadoma Branch</option>
                                  <option value="KWEKWE">Kwekwe Branch</option>
                                  <option value="MUTARE">Mutare Branch</option>
                                  <option value="GWERU">Gweru Branch</option>
                                  <option value="BULAWAYO">Bulawayo Branch</option>
                                  <option value="MASVINGO">Masvingo Branch</option>
                                  <option value="CHINHOYI">Chinhoyi Branch</option>
                                </select>
                          </td>
                          <td>

                            <input class="form__select" type="text" name="SerialNumber" placeholder="Serial Number">
                        </td>
                      </tr>
                      <tr>
                        <td>
                        <input type="date" name= "dop" value="Date" class="form__select">
                        <label></label>
                        </td>
                        <td>
                            <input style="background-color: light_grey;" class="form__select" type="text" name="assetType" value="Laptop" READONLY="TRUE">
                        </td>
                      </tr>
                      <tr>
                         <td></td>
                            <td>
                              <input class="btn" style="float:right; border-radius: 3px;position: absolute;z-index: 9;cursor: pointer;padding: 5px 20px;background-color: #6DBCDB;border: 1px solid #6DBCDB;color: #ffffff;font-size: 11px;text-transform: uppercase;margin-bottom: 10px;transition: .2s;" type="submit" name="laptop" value="add" placeholder="Add">
                            </td>
                          </tr>
                </table>
                
              </form>
                </div>
                
                <div id="Desktop" class="forms">
                <form action="add.php" method="POST" class="form">
                        <table>
                                <tr>
                                <td>
                                      <select class="form__select" name="supplier" id="select"  >
                                        <option value="">Supplier</option>
                                        <option value="Nashua">Nashua</option>
                                        <option value="Omni Africa">Omni Africa</option>
                                        <option value="Global Hrizons">Global Horizons</option>
                                      </select>
                                    </td>
                                        <td>
                                        <input type="date" name= "warranty" value="Date" class="form__select">
                                              </td>
                                      </tr>
                                      <tr>
                                            <td>
                                              <input class="form__select" type="text" name="UserName" placeholder="User Name">
                                            </td>
                                            <td>
                                              <input class="form__select" type="text" name="ComputerName" placeholder="Computer Name">
                                            </td>
                                          </tr>
                                          <tr>
                                                <td>
                                                 <select class="form__select" name="monitorModel" id="select"  >
                                                   <option value="">Monitor Model</option>
                                                   <option value="HP V196">HP V196</option>
                                                   <option value="HP V197">HP V197</option>
                                                 </select>
                                                </td>
                                                <td>
                                                 <input class="form__select" type="text" name="monitorSerial" placeholder="Monitor Serial Number">
                                               </td>
                                                
                                              </tr>
                                              <tr>
                                               <td>
                                                 <input class="form__select" type="text" name="keyboard" placeholder="Keyboard">
                                               </td>
                                               <td>
                                                 <input class="form__select" type="text" name="mouse" placeholder="Mouse">
                                               </td>
                                              </tr>
                                          <tr>
                                                <td>
                                                    <select class="form__select" name="make" id="selecta"  >
                                                        <option value="">Make</option>
                                                        <option value="HP">HP</option>
                                                        <option value="LENOVO">Lenovo</option>
                                                        <option value="DELL">DEll</option>
                                                      </select>
                                                </td>
                                                <td>
                                                    <select class="form__select" name="model" id="selectb"  >
                                                        <option value="">Model</option>
                                                        <option value="HP 450 G1">HP 450 G1</option>
                                                        <option value="HP 450 G1">HP 450 G2</option>
                                                        <option value="HP 450 G1">HP 850 G1</option>
                                                        <option value="HP 450 G1">HP 850 G2</option>
                                                        <option value="a">Select HP Model</option>
                                                        <option value="LENOVO">LENOVO</option>
                                                        <option value="b">Select LENOVO Model</option>
                                                        <option value="DELL LATTITUDE 5591">DELL LATTITUDE 5591</option>
                                                        <option value="DELL LATTITUDE 5590">DELL LATTITUDE 5590</option>
                                                        <option value="c">Select DELL Model</option>
                                                      </select>
                                                </td>
                                             </tr>
                                             <tr>
                                                    <td>
                                                      <select class="form__select" name="select" id="select"  >
                                                          <option value="">Operating System</option>
                                                          <option value="Windows 10">Windows 10</option>
                                                          <option value="Windows 8">Windows 8</option>
                                                          <option value="Windows 7">Windows 7</option>
                                                        </select>
                                                  </td>
                                                  <td>
                                                    <select class="form__select" name="processor" id="select"  >
                                                        <option value="">Processor</option>
                                                        <option value="CORE I7">core i7 </option>
                                                        <option value="CORE I5">core i5</option>
                                                        <option value="CORE I3">core i3</option>
                                                      </select>
                                                </td>
                                                  </tr>
                                                  <tr>
                                                    <td>
                                                      <select class="form__select" name="hdd" id="select"  >
                                                          <option value="">Hard Drive</option>
                                                          <option value="1TB">1TB</option>
                                                          <option value="500GB">500GB</option>
                                                          <option value="300GB">300GB</option>
                                                        </select>
                                                  </td>
                                                  <td>
                                                    <select class="form__select" name="ram" id="select"  >
                                                        <option value="">RAM</option>
                                                        <option value="2GB">2GB</option>
                                                        <option value="3GB">3GB</option>
                                                        <option value="4GB">4GB</option>
                                                        <option value="8GB">8GB</option>
                                                        <option value="12GB">12GB</option>
                                                        <option value="16">16GB</option>
                                                      </select>
                                                </td>
                                                  </tr>
                        </table>
                        <table >
                      <tr>
                          <td style="width:10%;">
                              <select class="form__select" name="company" id="select1"  >
                                  <option value="">Company</option>
                                  <option value="1">First Mutual Life</option>
                                  <option value="2">First Mutual Health</option>
                                  <option value="3">First Mutual Holdings</option>
                                  <option value="4">First Mutual Properties</option>
                                  <option value="5">First Mutual Wealth</option>
                                  <option value="6">First Mutual Reinsurance</option>
                                  <option value="7">Tristar Insurance</option>
                                  <option value="8">First Mutual Funeral</option>
                                </select>
                          </td>
                        
                          <td>
                              <select class="form__select" name="department" id="select2" >
                                  <option value="">Select Department</option>
                                  <option value="1">Finance</option>
                                  <option value="1">Individual Business</option>
                                  <option value="1">Employment Benefit</option>
                                  <option value="1">Human Resourse</option>
                                  <option value="1">Information Technology</option>
                                  <option value="1">Audit</option>
                                  <option value="1">Admin</option>
                                  <option value="1">Marketing</option>
                                  <option value="1">Call Center</option>
                                  <option value="1">Select Department</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Finance</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Select Department</option>
                                  <option value="3">Procurement</option>
                                  <option value="3">Finance</option>
                                  <option value="3">Select Department</option>
                                  <option value="4">Finance</option>
                                  <option value="4">Properties</option>
                                  <option value="4">Select Department</option>
                                  <option value="5">Front Office</option>
                                  <option value="5">Back Office</option>
                                  <option value="5">Finance</option>
                                  <option value="5">Select Department</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Select Department</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Select Department</option>
                                  <option value="8">Finance</option>
                                  <option value="8">Operations</option>
                                  <option value="8">Sales</option>
                                  <option value="8">Select Department</option>
              
                                </select>
                          </td>
                      </tr>
                      <tr>
                      <td>
                              <select class="form__select" name="branch" id="select1" >
                                  <option value="0">Branch</option>
                                  <option value="1">Head Office</option>
                                  <option value="2">99 Jason Moyo</option>
                                  <option value="3">Msasa Branch</option>
                                  <option value="4">Brynestone House</option>
                                  <option value="5">Kadoma Branch</option>
                                  <option value="5">Kwekwe Branch</option>
                                  <option value="6">Mutare Branch</option>
                                  <option value="7">Gweru Branch</option>
                                  <option value="8">Bulawayo Branch</option>
                                  <option value="8">Masvingo Branch</option>
                                  <option value="8">Chinhoyi Branch</option>
                                </select>
                          </td>
                          <td>

                            <input class="form__select" type="text" name="SerialNumber" placeholder="Serial Number">
                        </td>
                      </tr>
                      <tr>
                        <td>
                        <input type="date" name= "dop" value="Date" class="form__select">
                        </td>
                        <td>
                            <input style="background-color: white;" class="form__select" type="text" name="assetType" value="Desktop" READONLY="TRUE">
                        </td>
                      </tr>
                      <tr>
                         <td></td>
                            <td>
                              <input class="btn" style="float:right; border-radius: 3px;position: absolute;z-index: 9;cursor: pointer;padding: 5px 20px;background-color: #6DBCDB;border: 1px solid #6DBCDB;color: #ffffff;font-size: 11px;text-transform: uppercase;margin-bottom: 10px;transition: .2s;" type="submit" name="desktop" value="add" placeholder="Add">
                            </td>
                          </tr>
                </table>
                
              </form>
                </div>
                
                <div id="Printer" class="forms">
                <form action="add.php" method="POST" class="form">
                    <table>
                            <tr>
                            <td>
                                      <select class="form__select" name="supplier" id="select"  >
                                        <option value="">Supplier</option>
                                        <option value="1">Nashua</option>
                                        <option value="2">Omni Arica</option>
                                        <option value="3">Global Horizons</option>
                                      </select>
                                    </td>
                                    <td>
                                    <input type="date" name= "warranty" value="Date" class="form__select">
                                    </td>
                                  </tr>
                            <tr>
                                    <td>
                                        <select class="form__select" name="make" id="selecta"  >
                                            <option value="">Make</option>
                                            <option value="a">Kyocera</option>
                                            <option value="b">HP</option>
                                            <option value="c">Sumsung</option>
                                          </select>
                                    </td>
                                    <td>
                                        <select class="form__select" name="model" id="selectb"  >
                                            <option value="">Model</option>
                                            <option value="a">Kyocera Ecosys m3550 idn</option>
                                            <option value="a">Kyocera Ecosys m3550 idn</option>
                                            <option value="a">Kyocera Ecosys m3550 idn</option>
                                            <option value="a">Kyocera Ecosys m3550 idn</option>
                                            <option value="a">Select Kyocera Model</option>
                                            <option value="b">HP m227</option>
                                            <option value="b">Select HP Model</option>
                                            <option value="c">Sumsung 1</option>
                                            <option value="c">Sumsung 2</option>
                                            <option value="c">Select SUMSUNG Model</option>
                                          </select>
                                    </td>
                                 </tr>
                                 <tr>
                                   <td>
                                    <select class="form__select" name="connectionType" id="select" >
                                      <option value="">Connection Type</option>
                                      <option value="1">Local</option>
                                      <option value="2">Network</option>
                                    </select>
                                   </td>
                                   <td>
                                    <input class="form__select" type="text" name="ipaddress" placeholder="UserName or IP Address">
                                  </td>
                                   
                                 </tr>
                                <tr>
                                      <td>
                                        
                                        <input id="box1" type="checkbox" />
                                        <label for="box1">On Rental ?</label>
                                      </td>
                                  </tr>
                    </table>
                    <table >
                      <tr>
                          <td style="width:10%;">
                              <select class="form__select" name="company" id="select1"  >
                                  <option value="">Company</option>
                                  <option value="1">First Mutual Life</option>
                                  <option value="2">First Mutual Health</option>
                                  <option value="3">First Mutual Holdings</option>
                                  <option value="4">First Mutual Properties</option>
                                  <option value="5">First Mutual Wealth</option>
                                  <option value="6">First Mutual Reinsurance</option>
                                  <option value="7">Tristar Insurance</option>
                                  <option value="8">First Mutual Funeral</option>
                                </select>
                          </td>
                        
                          <td>
                              <select class="form__select" name="department" id="select2" >
                                  <option value="">Select Department</option>
                                  <option value="1">Finance</option>
                                  <option value="1">Individual Business</option>
                                  <option value="1">Employment Benefit</option>
                                  <option value="1">Human Resourse</option>
                                  <option value="1">Information Technology</option>
                                  <option value="1">Audit</option>
                                  <option value="1">Admin</option>
                                  <option value="1">Marketing</option>
                                  <option value="1">Call Center</option>
                                  <option value="1">Select Department</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Finance</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Select Department</option>
                                  <option value="3">Procurement</option>
                                  <option value="3">Finance</option>
                                  <option value="3">Select Department</option>
                                  <option value="4">Finance</option>
                                  <option value="4">Properties</option>
                                  <option value="4">Select Department</option>
                                  <option value="5">Front Office</option>
                                  <option value="5">Back Office</option>
                                  <option value="5">Finance</option>
                                  <option value="5">Select Department</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Select Department</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Select Department</option>
                                  <option value="8">Finance</option>
                                  <option value="8">Operations</option>
                                  <option value="8">Sales</option>
                                  <option value="8">Select Department</option>
              
                                </select>
                          </td>
                      </tr>
                      <tr>
                      <td>
                              <select class="form__select" name="branch" id="select1" >
                                  <option value="0">Branch</option>
                                  <option value="1">Head Office</option>
                                  <option value="2">99 Jason Moyo</option>
                                  <option value="3">Msasa Branch</option>
                                  <option value="4">Brynestone House</option>
                                  <option value="5">Kadoma Branch</option>
                                  <option value="5">Kwekwe Branch</option>
                                  <option value="6">Mutare Branch</option>
                                  <option value="7">Gweru Branch</option>
                                  <option value="8">Bulawayo Branch</option>
                                  <option value="8">Masvingo Branch</option>
                                  <option value="8">Chinhoyi Branch</option>
                                </select>
                          </td>
                          <td>

                            <input class="form__select" type="text" name="SerialNumber" placeholder="Serial Number">
                        </td>
                      </tr>
                      <tr>
                        <td>
                        <input type="date" name= "dop" value="Date" class="form__select">
                        </td>
                        <td>
                            <input style="background-color: white;" class="form__select" type="text" name="assetType" value="Printer" READONLY="TRUE">
                        </td>
                      </tr>
                      <tr>
                         <td></td>
                            <td>
                              <input class="btn" style="float:right; border-radius: 3px;position: absolute;z-index: 9;cursor: pointer;padding: 5px 20px;background-color: #6DBCDB;border: 1px solid #6DBCDB;color: #ffffff;font-size: 11px;text-transform: uppercase;margin-bottom: 10px;transition: .2s;" type="submit" name="printer" value="add" placeholder="Add">
                            </td>
                          </tr>
                </table>
                
              </form>
    
                </div>
    
                <div id="Server" class="forms">
                <form action="add.php" method="POST" class="form">
                        <table>
                                <tr>
                                <td>
                                      <select class="form__select" name="supplier" id="select"  >
                                        <option value="">Supplier</option>
                                        <option value="1">Nashua</option>
                                        <option value="2">Omni Arica</option>
                                        <option value="3">Global Horizons</option>
                                      </select>
                                    </td>
                                        <td>
                                        <input type="date" name= "warranty" value="Date" class="form__select">
                                              </td>
                                      </tr>
                                      <tr>
                                            <td>
                                              <input class="form__select" type="text" name="computerName" placeholder="Server Name">
                                            </td>
                                            <td>
                                              <input class="form__select" type="text" name="ipaddress" placeholder="IP Address">
                                            </td>
                                          </tr>
                                          <tr>
                                                <td>
                                                    <select class="form__select" name="make" id="selecta"  >
                                                        <option value="">Make</option>
                                                        <a href="index.html"><option value="a">HP</option></a>
                                                        <option value="b">Lenovo</option>
                                                        <option value="c">DEll</option>
                                                      </select>
                                                </td>
                                                <td>
                                                    <select class="form__select" name="model" id="selectb"  >
                                                        <option value="">Model</option>
                                                        <option value="a">HP 450 G1</option>
                                                        <option value="a">HP 450 G2</option>
                                                        <option value="a">HP 850 G1</option>
                                                        <option value="a">HP 850 G2</option>
                                                        <option value="a">Select HP Model</option>
                                                        <option value="b">LENOVO</option>
                                                        <option value="b">Select LENOVO Model</option>
                                                        <option value="c">DELL LATTITUDE 5591</option>
                                                        <option value="c">DELL LATTITUDE 5590</option>
                                                        <option value="c">Select DELL Model</option>
                                                      </select>
                                                </td>
                                             </tr>
                                             <tr>
                                                    <td>
                                                      <select class="form__select" name="os" id="select"  >
                                                          <option value="">Operating System</option>
                                                          <option value="1">Windows 10</option>
                                                          <option value="2">Windows 8</option>
                                                          <option value="3">Windows 7</option>
                                                        </select>
                                                  </td>
                                                  <td>
                                                    <select class="form__select" name="processor" id="select"  >
                                                        <option value="">Processor</option>
                                                        <option value="1">core i7 </option>
                                                        <option value="2">core i5</option>
                                                        <option value="3">core i3</option>
                                                      </select>
                                                </td>
                                                  </tr>
                                                  <tr>
                                                    <td>
                                                      <select class="form__select" name="hdd" id="select"  >
                                                          <option value="">Hard Drive</option>
                                                          <option value="1">1TB</option>
                                                          <option value="2">500GB</option>
                                                          <option value="3">300GB</option>
                                                        </select>
                                                  </td>
                                                  <td>
                                                    <select class="form__select" name="ram" id="select"  >
                                                        <option value="">RAM</option>
                                                        <option value="1">2GB</option>
                                                        <option value="2">3GB</option>
                                                        <option value="3">4GB</option>
                                                        <option value="1">8GB</option>
                                                        <option value="2">12GB</option>
                                                        <option value="3">16GB</option>
                                                      </select>
                                                </td>
                                                  </tr>
                        </table>
                        <table >
                      <tr>
                          <td style="width:10%;">
                              <select class="form__select" name="company" id="select1"  >
                                  <option value="">Company</option>
                                  <option value="1">First Mutual Life</option>
                                  <option value="2">First Mutual Health</option>
                                  <option value="3">First Mutual Holdings</option>
                                  <option value="4">First Mutual Properties</option>
                                  <option value="5">First Mutual Wealth</option>
                                  <option value="6">First Mutual Reinsurance</option>
                                  <option value="7">Tristar Insurance</option>
                                  <option value="8">First Mutual Funeral</option>
                                </select>
                          </td>
                        
                          <td>
                              <select class="form__select" name="department" id="select2" >
                                  <option value="">Select Department</option>
                                  <option value="1">Finance</option>
                                  <option value="1">Individual Business</option>
                                  <option value="1">Employment Benefit</option>
                                  <option value="1">Human Resourse</option>
                                  <option value="1">Information Technology</option>
                                  <option value="1">Audit</option>
                                  <option value="1">Admin</option>
                                  <option value="1">Marketing</option>
                                  <option value="1">Call Center</option>
                                  <option value="1">Select Department</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Finance</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Select Department</option>
                                  <option value="3">Procurement</option>
                                  <option value="3">Finance</option>
                                  <option value="3">Select Department</option>
                                  <option value="4">Finance</option>
                                  <option value="4">Properties</option>
                                  <option value="4">Select Department</option>
                                  <option value="5">Front Office</option>
                                  <option value="5">Back Office</option>
                                  <option value="5">Finance</option>
                                  <option value="5">Select Department</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Select Department</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Select Department</option>
                                  <option value="8">Finance</option>
                                  <option value="8">Operations</option>
                                  <option value="8">Sales</option>
                                  <option value="8">Select Department</option>
              
                                </select>
                          </td>
                      </tr>
                      <tr>
                      <td>
                              <select class="form__select" name="branch" id="select1" >
                                  <option value="0">Branch</option>
                                  <option value="1">Head Office</option>
                                  <option value="2">99 Jason Moyo</option>
                                  <option value="3">Msasa Branch</option>
                                  <option value="4">Brynestone House</option>
                                  <option value="5">Kadoma Branch</option>
                                  <option value="5">Kwekwe Branch</option>
                                  <option value="6">Mutare Branch</option>
                                  <option value="7">Gweru Branch</option>
                                  <option value="8">Bulawayo Branch</option>
                                  <option value="8">Masvingo Branch</option>
                                  <option value="8">Chinhoyi Branch</option>
                                </select>
                          </td>
                          <td>

                            <input class="form__select" type="text" name="SerialNumber" placeholder="Serial Number">
                        </td>
                      </tr>
                      <tr>
                        <td>
                        <input type="date" name= "dop" value="Date" class="form__select">
                        </td>
                        <td>
                            <input style="background-color: white;" class="form__select" type="text" name="assetType" value="Server" READONLY="TRUE">
                        </td>
                      </tr>
                      <tr>
                         <td></td>
                            <td>
                              <input class="btn" style="float:right; border-radius: 3px;position: absolute;z-index: 9;cursor: pointer;padding: 5px 20px;background-color: #6DBCDB;border: 1px solid #6DBCDB;color: #ffffff;font-size: 11px;text-transform: uppercase;margin-bottom: 10px;transition: .2s;" type="submit" name="server" value="add" placeholder="Add">
                            </td>
                          </tr>
                </table>
                
              </form>
                  </div>
    
                <div id="Ipad" class="forms">
                <form action="add.php" method="POST" class="form">
                    <table>
                            <tr>
                                    <td>
                                      <select class="form__select" name="supplier" id="select"  >
                                        <option value="">Supplier</option>
                                        <option value="1">Nashua</option>
                                        <option value="2">Omni Arica</option>
                                        <option value="3">Global Horizons</option>
                                      </select>
                                    </td>
                                    <td>
                                    <input class="form__select" type="text" name="UserName" placeholder="User Name">
                                    </td>
                                  </tr>
                            <tr>
                                    <td>
                                        <select class="form__select" name="make" id="make"  >
                                            <option value="">Make</option>
                                            <a href="index.html"><option value="a">Sumsung</option></a>
                                            <option value="b">Lenovo</option>
                                            <option value="c">Apple</option>
                                          </select>
                                    </td>
                                    <td>
                                        <select class="form__select" name="model" id="selectb"  >
                                            <option value="">Model</option>
                                            <option value="a">Sumsung tab 3</option>
                                            <option value="a">Sumsung tab 2</option>
                                            <option value="a">Select SUMSUNG Model</option>
                                            <option value="b">LENOVO</option>
                                            <option value="b">Apple 9.7</option>
                                            <option value="c">Apple 10.5</option>
                                            <option value="c">Select APPLE Model</option>
                                          </select>
                                    </td>
                                 </tr>
                                <tr>
                                      <td>
                                          <select class="form__select" name="os" id="select"  >
                                              <option value="">Operating System</option>
                                              <option value="1">Android</option>
                                              <option value="2">IOS</option>
                                              <option value="3">Windows</option>
                                            </select>
                                      </td>
                                     
                                  </tr>
                                  <tr>
                                    <td>
                                      
                                      <select class="form__select" name="hdd" id="select"  >
                                          <option value="">Hard Drive</option>
                                          <option value="1">16GB</option>
                                          <option value="2">32GB</option>
                                          <option value="3">64GB</option>
                                          <option value="3">128GB</option>
                                        </select>
                                  </td>
                                  <td>
                                    
                                    <select class="form__select" name="ram" id="select"  >
                                        <option value="">RAM</option>
                                        <option value="1">1GB</option>
                                        <option value="2">2GB</option>
                                        <option value="3">3GB</option>
                                        <option value="1">4GB</option>
                                        <option value="2">8GB</option>
                                        <option value="3">16GB</option>
                                      </select>
                                </td>
                                  </tr>
                                  <tr>
                                    <td>
                                    <input type="date" name= "warranty" value="Date" class="form__select">
                                      
                                  </td>
                                  <td>
                                    <input class="form__select" type="text" name="Additional" placeholder="Additionals">
                                </td>
                                  </tr>
                    </table>
                    <table >
                      <tr>
                          <td style="width:10%;">
                              <select class="form__select" name="company" id="select1"  >
                                  <option value="">Company</option>
                                  <option value="1">First Mutual Life</option>
                                  <option value="2">First Mutual Health</option>
                                  <option value="3">First Mutual Holdings</option>
                                  <option value="4">First Mutual Properties</option>
                                  <option value="5">First Mutual Wealth</option>
                                  <option value="6">First Mutual Reinsurance</option>
                                  <option value="7">Tristar Insurance</option>
                                  <option value="8">First Mutual Funeral</option>
                                </select>
                          </td>
                        
                          <td>
                              <select class="form__select" name="department" id="select2" >
                                  <option value="">Select Department</option>
                                  <option value="1">Finance</option>
                                  <option value="1">Individual Business</option>
                                  <option value="1">Employment Benefit</option>
                                  <option value="1">Human Resourse</option>
                                  <option value="1">Information Technology</option>
                                  <option value="1">Audit</option>
                                  <option value="1">Admin</option>
                                  <option value="1">Marketing</option>
                                  <option value="1">Call Center</option>
                                  <option value="1">Select Department</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Finance</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Select Department</option>
                                  <option value="3">Procurement</option>
                                  <option value="3">Finance</option>
                                  <option value="3">Select Department</option>
                                  <option value="4">Finance</option>
                                  <option value="4">Properties</option>
                                  <option value="4">Select Department</option>
                                  <option value="5">Front Office</option>
                                  <option value="5">Back Office</option>
                                  <option value="5">Finance</option>
                                  <option value="5">Select Department</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Select Department</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Select Department</option>
                                  <option value="8">Finance</option>
                                  <option value="8">Operations</option>
                                  <option value="8">Sales</option>
                                  <option value="8">Select Department</option>
              
                                </select>
                          </td>
                      </tr>
                      <tr>
                      <td>
                              <select class="form__select" name="branch" id="select1" >
                                  <option value="0">Branch</option>
                                  <option value="1">Head Office</option>
                                  <option value="2">99 Jason Moyo</option>
                                  <option value="3">Msasa Branch</option>
                                  <option value="4">Brynestone House</option>
                                  <option value="5">Kadoma Branch</option>
                                  <option value="5">Kwekwe Branch</option>
                                  <option value="6">Mutare Branch</option>
                                  <option value="7">Gweru Branch</option>
                                  <option value="8">Bulawayo Branch</option>
                                  <option value="8">Masvingo Branch</option>
                                  <option value="8">Chinhoyi Branch</option>
                                </select>
                          </td>
                          <td>

                            <input class="form__select" type="text" name="SerialNumber" placeholder="Serial Number">
                        </td>
                      </tr>
                      <tr>
                        <td>
                        <input type="date" name= "dop" value="Date" class="form__select">
                        </td>
                        <td>
                            <input style="background-color: white;" class="form__select" type="text" name="assetType" value="Ipad / Tablet" READONLY="TRUE">
                        </td>
                      </tr>
                      <tr>
                         <td></td>
                            <td>
                              <input class="btn" style="float:right; border-radius: 3px;position: absolute;z-index: 9;cursor: pointer;padding: 5px 20px;background-color: #6DBCDB;border: 1px solid #6DBCDB;color: #ffffff;font-size: 11px;text-transform: uppercase;margin-bottom: 10px;transition: .2s;" type="submit" name="tablet" value="add" placeholder="Add">
                            </td>
                          </tr>
                </table>
                
              </form>
                </div>
                  
                <div id="Router" class="forms">
                <form action="add.php" method="POST" class="form"> 
                    <table>
                            <tr>
                            <td>
                                      <select class="form__select" name="supplier" id="select"  >
                                        <option value="">Supplier</option>
                                        <option value="1">Nashua</option>
                                        <option value="2">Omni Arica</option>
                                        <option value="3">Global Horizons</option>
                                      </select>
                                    </td>
                                    <td>
                                    <input class="form__select" type="text" name="ipadress" placeholder="IP Address">
                                    </td>
                                  </tr>
                                  <tr>
                                   
                                    <td>
                                    <select class="form__select" name="model" id="selectb"  >
                                                <option value="">Model</option>
                                                <option value="a">Cisco model 1</option>
                                                <option value="a">Cisco model 2</option>
                                              </select>
                                    </td>
                                  </tr>
                                  <tr>
                                        <td>
                                        <select class="form__select" name="os" id="select"  >
                                                <option value="">IOS Version</option>
                                                <option value="1">IOS Version 1</option>
                                                <option value="2">IOS version 2</option>
                                              </select>
                                        </td>
                                     </tr>

                    </table>
                    <table >
                      <tr>
                          <td style="width:10%;">
                              <select class="form__select" name="company" id="select1"  >
                                  <option value="">Company</option>
                                  <option value="1">First Mutual Life</option>
                                  <option value="2">First Mutual Health</option>
                                  <option value="3">First Mutual Holdings</option>
                                  <option value="4">First Mutual Properties</option>
                                  <option value="5">First Mutual Wealth</option>
                                  <option value="6">First Mutual Reinsurance</option>
                                  <option value="7">Tristar Insurance</option>
                                  <option value="8">First Mutual Funeral</option>
                                </select>
                          </td>
                        
                          <td>
                              <select class="form__select" name="department" id="select2" >
                                  <option value="">Select Department</option>
                                  <option value="1">Finance</option>
                                  <option value="1">Individual Business</option>
                                  <option value="1">Employment Benefit</option>
                                  <option value="1">Human Resourse</option>
                                  <option value="1">Information Technology</option>
                                  <option value="1">Audit</option>
                                  <option value="1">Admin</option>
                                  <option value="1">Marketing</option>
                                  <option value="1">Call Center</option>
                                  <option value="1">Select Department</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Finance</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Select Department</option>
                                  <option value="3">Procurement</option>
                                  <option value="3">Finance</option>
                                  <option value="3">Select Department</option>
                                  <option value="4">Finance</option>
                                  <option value="4">Properties</option>
                                  <option value="4">Select Department</option>
                                  <option value="5">Front Office</option>
                                  <option value="5">Back Office</option>
                                  <option value="5">Finance</option>
                                  <option value="5">Select Department</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Select Department</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Select Department</option>
                                  <option value="8">Finance</option>
                                  <option value="8">Operations</option>
                                  <option value="8">Sales</option>
                                  <option value="8">Select Department</option>
              
                                </select>
                          </td>
                      </tr>
                      <tr>
                      <td>
                              <select class="form__select" name="branch" id="select1" >
                                  <option value="0">Branch</option>
                                  <option value="1">Head Office</option>
                                  <option value="2">99 Jason Moyo</option>
                                  <option value="3">Msasa Branch</option>
                                  <option value="4">Brynestone House</option>
                                  <option value="5">Kadoma Branch</option>
                                  <option value="5">Kwekwe Branch</option>
                                  <option value="6">Mutare Branch</option>
                                  <option value="7">Gweru Branch</option>
                                  <option value="8">Bulawayo Branch</option>
                                  <option value="8">Masvingo Branch</option>
                                  <option value="8">Chinhoyi Branch</option>
                                </select>
                          </td>
                          <td>

                            <input class="form__select" type="text" name="SerialNumber" placeholder="Serial Number">
                        </td>
                      </tr>
                      <tr>
                        <td>
                        <input type="date" name= "dop" value="Date" class="form__select">
                        </td>
                        <td>
                            <input style="background-color: white;" class="form__select" type="text" name="assetType" value="Router" READONLY="TRUE">
                        </td>
                      </tr>
                      <tr>
                         <td></td>
                            <td>
                              <input class="btn" style="float:right; border-radius: 3px;position: absolute;z-index: 9;cursor: pointer;padding: 5px 20px;background-color: #6DBCDB;border: 1px solid #6DBCDB;color: #ffffff;font-size: 11px;text-transform: uppercase;margin-bottom: 10px;transition: .2s;" type="submit" name="router" value="add" placeholder="Add">
                            </td>
                          </tr>
                </table>
                
              </form>
                </div>
    
                <div id="Switch" class="forms">
                <form action="add.php" method="POST" class="form">
                    <table>
                            <tr>
                            <td>
                                      <select class="form__select" name="supplier" id="select"  >
                                        <option value="">Supplier</option>
                                        <option value="1">Nashua</option>
                                        <option value="2">Omni Arica</option>
                                        <option value="3">Global Horizons</option>
                                      </select>
                                    </td>
                                    <td>
                                    <select class="form__select" name="model" id="selectb"  >
                                                <option value="">Model</option>
                                                <option value="a">Cisco model 1</option>
                                                <option value="a">Cisco model 2</option>
                                              </select>
                                    </td>
                                  </tr>
                                  <tr>
                                    
                                    <td>
                                            <select class="form__select" name="os" id="select"  >
                                                <option value="">IOS Version</option>
                                                <option value="1">IOS Version 1</option>
                                                <option value="2">IOS version 2</option>
                                              </select>
                                          
                                      </td>
                                  </tr>
                    </table>
                    <table >
                      <tr>
                          <td style="width:10%;">
                              <select class="form__select" name="company" id="select1"  >
                                  <option value="">Company</option>
                                  <option value="1">First Mutual Life</option>
                                  <option value="2">First Mutual Health</option>
                                  <option value="3">First Mutual Holdings</option>
                                  <option value="4">First Mutual Properties</option>
                                  <option value="5">First Mutual Wealth</option>
                                  <option value="6">First Mutual Reinsurance</option>
                                  <option value="7">Tristar Insurance</option>
                                  <option value="8">First Mutual Funeral</option>
                                </select>
                          </td>
                        
                          <td>
                              <select class="form__select" name="department" id="select2" >
                                  <option value="">Select Department</option>
                                  <option value="1">Finance</option>
                                  <option value="1">Individual Business</option>
                                  <option value="1">Employment Benefit</option>
                                  <option value="1">Human Resourse</option>
                                  <option value="1">Information Technology</option>
                                  <option value="1">Audit</option>
                                  <option value="1">Admin</option>
                                  <option value="1">Marketing</option>
                                  <option value="1">Call Center</option>
                                  <option value="1">Select Department</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Finance</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Select Department</option>
                                  <option value="3">Procurement</option>
                                  <option value="3">Finance</option>
                                  <option value="3">Select Department</option>
                                  <option value="4">Finance</option>
                                  <option value="4">Properties</option>
                                  <option value="4">Select Department</option>
                                  <option value="5">Front Office</option>
                                  <option value="5">Back Office</option>
                                  <option value="5">Finance</option>
                                  <option value="5">Select Department</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Select Department</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Select Department</option>
                                  <option value="8">Finance</option>
                                  <option value="8">Operations</option>
                                  <option value="8">Sales</option>
                                  <option value="8">Select Department</option>
              
                                </select>
                          </td>
                      </tr>
                      <tr>
                      <td>
                              <select class="form__select" name="branch" id="select1" >
                                  <option value="0">Branch</option>
                                  <option value="1">Head Office</option>
                                  <option value="2">99 Jason Moyo</option>
                                  <option value="3">Msasa Branch</option>
                                  <option value="4">Brynestone House</option>
                                  <option value="5">Kadoma Branch</option>
                                  <option value="5">Kwekwe Branch</option>
                                  <option value="6">Mutare Branch</option>
                                  <option value="7">Gweru Branch</option>
                                  <option value="8">Bulawayo Branch</option>
                                  <option value="8">Masvingo Branch</option>
                                  <option value="8">Chinhoyi Branch</option>
                                </select>
                          </td>
                          <td>

                            <input class="form__select" type="text" name="SerialNumber" placeholder="Serial Number">
                        </td>
                      </tr>
                      <tr>
                        <td>
                        <input type="date" name= "dop" value="Date" class="form__select">
                        </td>
                        <td>
                            <input style="background-color: white;" class="form__select" type="text" name="assetType" value="Switch" READONLY="TRUE">
                        </td>
                      </tr>
                      <tr>
                         <td></td>
                            <td>
                              <input class="btn" style="float:right; border-radius: 3px;position: absolute;z-index: 9;cursor: pointer;padding: 5px 20px;background-color: #6DBCDB;border: 1px solid #6DBCDB;color: #ffffff;font-size: 11px;text-transform: uppercase;margin-bottom: 10px;transition: .2s;" type="submit" name="switch" value="add" placeholder="Add">
                            </td>
                          </tr>
                </table>
                
              </form>
                </div>
                <div id="Projector" class="forms">
                <form action="add.php" method="POST" class="form">
                    <table >
                            <tr>
                            <td>
                                      <select class="form__select" name="supplier" id="select"  >
                                        <option value="">Supplier</option>
                                        <option value="1">Nashua</option>
                                        <option value="2">Omni Arica</option>
                                        <option value="3">Global Horizons</option>
                                      </select>
                                    </td>
                                    <td>
                                      <input class="form__select" type="text" name="UserName" placeholder="Custodian">
                                    </td>
                                  </tr>
                                  <tr>
                                        <td>
                                            <select class="form__select" name="make" id="selecta"  >
                                                <option value="">Make</option>
                                                <a><option value="a">Epson</option></a>
                                              </select>
                                        </td>
                                        <td>
                                            <select class="form__select" name="model" id="selectb"  >
                                                <option value="">Model</option>
                                                <option value="a">Sumsung tab 3</option>
                                                <option value="a">Sumsung tab 2</option>
                                                <option value="a">Select SUMSUNG Model</option>
                                                <option value="b">LENOVO</option>
                                                <option value="b">Apple 9.7</option>
                                                <option value="c">Apple 10.5</option>
                                                <option value="c">Select APPLE Model</option>
                                              </select>
                                        </td>
                                     </tr>
                                      <tr>
                                        <td>
                                        <input type="date" name= "warranty" value="Date" class="form__select">
                                          
                                      </td>
                                      </tr>
                    </table>
                    <table >
                      <tr>
                          <td style="width:10%;">
                              <select class="form__select" name="company" id="select1"  >
                                  <option value="">Company</option>
                                  <option value="1">First Mutual Life</option>
                                  <option value="2">First Mutual Health</option>
                                  <option value="3">First Mutual Holdings</option>
                                  <option value="4">First Mutual Properties</option>
                                  <option value="5">First Mutual Wealth</option>
                                  <option value="6">First Mutual Reinsurance</option>
                                  <option value="7">Tristar Insurance</option>
                                  <option value="8">First Mutual Funeral</option>
                                </select>
                          </td>
                        
                          <td>
                              <select class="form__select" name="department" id="select2" >
                                  <option value="">Select Department</option>
                                  <option value="1">Finance</option>
                                  <option value="1">Individual Business</option>
                                  <option value="1">Employment Benefit</option>
                                  <option value="1">Human Resourse</option>
                                  <option value="1">Information Technology</option>
                                  <option value="1">Audit</option>
                                  <option value="1">Admin</option>
                                  <option value="1">Marketing</option>
                                  <option value="1">Call Center</option>
                                  <option value="1">Select Department</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Finance</option>
                                  <option value="2">Marketing</option>
                                  <option value="2">Select Department</option>
                                  <option value="3">Procurement</option>
                                  <option value="3">Finance</option>
                                  <option value="3">Select Department</option>
                                  <option value="4">Finance</option>
                                  <option value="4">Properties</option>
                                  <option value="4">Select Department</option>
                                  <option value="5">Front Office</option>
                                  <option value="5">Back Office</option>
                                  <option value="5">Finance</option>
                                  <option value="5">Select Department</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Finance</option>
                                  <option value="6">Select Department</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Finance</option>
                                  <option value="7">Select Department</option>
                                  <option value="8">Finance</option>
                                  <option value="8">Operations</option>
                                  <option value="8">Sales</option>
                                  <option value="8">Select Department</option>
              
                                </select>
                          </td>
                      </tr>
                      <tr>
                      <td>
                              <select class="form__select" name="branch" id="select1" >
                                  <option value="0">Branch</option>
                                  <option value="1">Head Office</option>
                                  <option value="2">99 Jason Moyo</option>
                                  <option value="3">Msasa Branch</option>
                                  <option value="4">Brynestone House</option>
                                  <option value="5">Kadoma Branch</option>
                                  <option value="5">Kwekwe Branch</option>
                                  <option value="6">Mutare Branch</option>
                                  <option value="7">Gweru Branch</option>
                                  <option value="8">Bulawayo Branch</option>
                                  <option value="8">Masvingo Branch</option>
                                  <option value="8">Chinhoyi Branch</option>
                                </select>
                          </td>
                          <td>

                            <input class="form__select" type="text" name="SerialNumber" placeholder="Serial Number">
                        </td>
                      </tr>
                      <tr>
                        <td>
                        <input type="date" name= "dop" value="Date" class="form__select">
                        </td>
                        <td>
                            <input style="background-color: white;" class="form__select" type="text" name="assetType" value="Projector" READONLY="TRUE">
                        </td>
                      </tr>
                      <tr>
                         <td></td>
                            <td>
                              <input class="btn" style="float:right; border-radius: 3px;position: absolute;z-index: 9;cursor: pointer;padding: 5px 20px;background-color: #6DBCDB;border: 1px solid #6DBCDB;color: #ffffff;font-size: 11px;text-transform: uppercase;margin-bottom: 10px;transition: .2s;" type="submit" name="projector" value="add" placeholder="Add">
                            </td>
                          </tr>
                </table>
                
              </form>
                </div>
                
            </div>
          </div>



          <div class="well animated zoomIn">
            <h4>Disk Space Used</h4>
            <div class="progress">
              <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
                <span class="sr-only">60% Complete</span>
              </div>
            </div>
            <h4>Bandwidth Used</h4>
            <div class="progress">
              <div class="progress-bar" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%;">
                <span class="sr-only">40% Complete</span>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-9">
          <div class="panel panel-default animated zoomIn">
            <div class="panel-heading main-color-bg">
              <h3 class="panel-title">Statistics</h3>
            </div>
           <table>
           <tr>
           <td><div id="piechart" style="width: 400px; height: 250px;"></div></td>
           <td><div id="piechart1" style="width: 400px; height: 250px;"></div></td>
           </tr>
           </table>
		   
          </div>
          <div class="panel panel-default animated zoomIn">
            <!-- Default panel contents -->
            <div class="panel-heading main-color-bg">Recently Added</div>
            <div class="panel-body">
              <!-- Table -->
              <table class="table table-striped table-hover">
              <tr>
              <th>Date Of Purchase</th>
                <th>Type</th>
                  <th>Model</th>
                  <th>Serial Number</th>
                  <th>Company</th>
                  <th>Logged By</th>
                  <th>Status</th>
 </tr>
 <?php
$conn = mysqli_connect("localhost", "root", "", "assetregister");
  // Check connection
  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  } 
  $sql = "SELECT model, type, serialNumber, company, loggedBy,dop,status FROM asset order by dop DESC LIMIT 8";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
   // output data of each row
   while($row = $result->fetch_assoc()) {
    echo "<tr>
    <td>" . $row["dop"]. "</td>
    <td>" . $row["type"]. "</td>
    <td>" . $row["model"] . "</td>
    <td>" . $row["serialNumber"]. "</td>
    <td>" . $row["company"]. "</td>
    <td>" . $row["loggedBy"]. "</td>
    <td>" . $row["status"]. "</td>
    </tr>";
}
echo "</table>";
} //else { echo "0 results"; }
$conn->close();
?>
</table>

            </div>
			
          </div>
		  <a href="Search.php"><button type="button" class="btn btn-primary">View Assets</button></a>
        </div>
      </div>
  </section>

  <!-- footer -->
  <footer id="footer">
    <p>&copy; Developed by <i><strong>FML GCIT</p>
    </footer>



  <!-- Model -->
  <!-- Add page -->
  <div class="modal fade" id="addPage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <form>
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">Add page</h4>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label>Page Title</label>
              <input type="text" class="form-control" placeholder="Page Title">
            </div>
            <div class="form-group">
              <label>Page Body</label>
              <textarea name="editor1" class="form-control" placeholder="Page Body"></textarea>
            </div>
            <div class="checkbox">
              <label>
          <input type="checkbox"> Published
        </label>
            </div>
            <div class="form-group">
              <label>Meta Tags</label>
              <input type="text" class="form-control" placeholder="Add Some Tags...">
            </div>
            <div class="form-group">
              <label>Meta Description</label>
              <input type="text" class="form-control" placeholder="Add Meta Description...">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Save changes</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  
  
 
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js'></script>

  

    <script  src="js/index.js"></script>
    <script  src="js/indexpopup.js"></script>
    <script  src="js/indexform.js"></script>




</body>

</html>
