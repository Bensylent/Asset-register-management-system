<?php	

$company = $_POST['company'];
$company = $_POST['company'];
$username = $_POST['username'];
$compDescription = $_POST['compDescription'];
$compSerial = $_POST['compSerial'];
$monitorModel = $_POST['monitorModel'];
$monitorSerial = $_POST['monitorSerial'];
$date = $_POST['date'];
$compName = $_POST['compName'];

$os = $_POST['os'];
$processor = $_POST['processor'];
$hdd = $_POST['hdd'];
$dop = $_POST['dop'];
$ram = $_POST['ram'];
$allocationReason = $_POST['allocationReason'];

require ('fpdf17/fpdf.php');

class PDF extends FPDF{
	function Header(){
		$this->SetFont('Arial','B',12);
		//$this->Cell(12);
		//$this->Image('logo.jpg',1,1,50,'C');
		$path = 'logo.jpg';
		$this->SetXY(100,30);
        $this->Image($path,80,2,50);
		
		$this->Cell(10,5,'Computer Handover Checklist',0,1);
	}
	
	
	function Footer(){
		$this->SetFont ('Arial','B',10);
		$this->Cell(30,5,'ICT Personnel',0,0);
		$this->Cell(90,5,'Name: ....................................................',0,0);
		$this->Cell(90,5,'Signature : ..............................................',0,1);
		$this->Ln();
		
		$this->Cell(30,5,'User',0,0);
		$this->Cell(90,5,'Name: ....................................................',0,0);
		$this->Cell(90,5,'Signature : ..............................................',0,1);
		$this->Ln();
		
		$this->Cell(30,5,'ICT Manager',0,0);
		$this->Cell(90,5,'Name: ....................................................',0,0);
		$this->Cell(90,5,'Signature : ..............................................',0,1);
		$this->Ln();
	}

	
function headerTable(){
    $this->Ln();
	$this->Ln();
	$this->Ln();
	$this->Ln();

	$this->SetFont('Arial','B',9);
	$this->Cell(20,10,"Item",1,0,'C');
	$this->Cell(90,10,"Task",1,0,'C');
	$this->Cell(40,10,"Technician Check",1,0,'C');
	$this->Cell(40,10,"User Check",1,0,'C');
	$this->Ln();
}

function viewTable(){

	$this->SetFont('Arial','',9);
	$this->Cell(20,6,"1",1,0,'C');
	$this->Cell(90,6,"Old Data Restored",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,6,"2",1,0,'C');
	$this->Cell(90,6,"Mapped Network Drives",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,6,"3",1,0,'C');
	$this->Cell(90,6,"Installed Antivirus",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,6,"4",1,0,'C');
	$this->Cell(90,6,"Installed Office",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,6,"5",1,0,'C');
	$this->Cell(90,6,"Installed PDF Softwate",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,6,"6",1,0,'C');
	$this->Cell(90,6,"Installed Printers",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,6,"7",1,0,'C');
	$this->Cell(90,6,"Configured Email",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,6,"8",1,0,'C');
	$this->Cell(90,6,"System 1:",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,6,"9",1,0,'C');
	$this->Cell(90,6,"System 2:",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,6,"10",1,0,'C');
	$this->Cell(90,6,"System 3:",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Cell(40,6," ",1,0,'C');
	$this->Ln();
	$this->Ln();
	$this->Ln();
	
}



}



$pdf = new PDF('P','mm','A4');
$pdf->AddPage();

$pdf->Image('Watermark.png',20,100,145);


$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Company :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$company,1,0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Username :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$username,1,1);

$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Computer Description :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$compDescription,1,0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Computer Serial Number :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$compSerial,1,1);

$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Monitor Model :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$monitorModel,1,0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Monitor Serial Number :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$monitorSerial,1,1);

$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Date :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$date,1,0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Computer Name :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$compName,1,1);

$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Operating System :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$os,1,0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Hard Drive :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$hdd,1,1);

$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Date Of Purchase :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$dop,1,0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Processor :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$processor,1,1);

$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"Reason For Allocation :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$allocationReason,1,0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45,6,"RAM :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(45,6,$ram,1,1);

$pdf->headerTable();
$pdf->viewTable();
$pdf->output();
	
?>