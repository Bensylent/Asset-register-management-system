

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Computer Handover Form</title>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
 <!-- <link rel="stylesheet" href="css/reset.min"> -->
  
      <link rel="stylesheet" href="css/style.css">
	   <link rel='stylesheet' href='https://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css'>

      

  
</head>

<body>

  <h1>Computer Handover Form</h1>
  	
 
 <form method="GET" action="comphandover.php">
<input type="text" name="search" placeholder="Enter Serial Number..."/>
<input type="submit" value="search">
 </form>
 
 <script src='https://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js'></script>
<script src='https://code.jquery.com/jquery-1.10.2.min.js'></script>

  

    

</body>

</html>

<?php


if(isset($_GET['search']))
{
$search=$_GET["search"]; 

$con=mysqli_connect("localhost","root","","assetregister");


if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result=mysqli_query($con,"select * from asset where `serialNumber` = '$search'"); 

while($row=mysqli_fetch_assoc($result))
{
    echo'<form class="cf" action="comphandovergen.php" method="post">';
	echo'<div class="half left cf">';
    
    echo'<input type="text" class="text" name="company" id="input-name" value='. $row["company"].'>';
    echo'<input type="text" class="text" name="company" id="input-name" value='. $row["dop"].'><br>';
	echo'<input type="text" class="text" name="username" id="input-name" value='. $row["currentUser"].'>';
	echo'<input type="text" class="text" name="compDescription" id="input-name" value='. $row["type"].'>';
	echo'<input type="text" class="text" name="compSerial" id="input-name" value='. $row["serialNumber"].'>';
	echo'<input type="text" class="text" name="monitorSerial" id="input-name" value='. $row["monitorSerial"].'>';
	echo'<input type="text" class="text" name="dop" id="input-name" value='. $row["dop"].'>';
	echo'<input type="text" class="text" name="compName" id="input-name" value='. $row["computerName"].'>';
	echo'</div>';
	
	
	echo'<div class="half right cf">';
    
    echo'<input type="text" class="text" name="os" id="input-name" value='. $row["os"].'>';
    echo'<input type="text" class="text" name="processor" id="input-name" value='. $row["processor"].'>';
	echo'<input type="text" class="text" name="hdd" id="input-name" value='. $row["hdd"].'>';
	echo'<input type="text" class="text" name="ram" id="input-name" value='. $row["ram"].'>';
	echo'<input type="text" class="text" name="monitorModel" id="input-name" value='. $row["monitorModel"].'>';
	echo'<input type="date" name="date" id="input-name"  placeholder="Date" required>';
	echo'<textarea name="allocationReason" type="text" id="input-message" placeholder="Reason For Allocation:" required></textarea>';
	
	
	echo'</div>';
	echo' <input type="submit" value="Submit" id="input-submit">';
	
	echo'</form>';
	
}

} 

?>
