<?php
 include 'database.php'; 
if (isset($_POST['edit'])){
    $currentUser = $_POST['currentUser'];
    $computerName = $_POST['computerName'];
    $supplier = $_POST['supplier'];
    $model = $_POST['model'];
    $os = $_POST['os'];
    $processor = $_POST['processor'];
    $hdd = $_POST['hdd'];
    $ram = $_POST['ram'];
    $warranty = $_POST['warranty'];
    $branch = $_POST['branch'];
    $ipaddress = $_POST['ipaddress'];
    $monitorSerial = $_POST['monitorSerial'];
    $monitorModel = $_POST['monitorModel'];
    $keyboard = $_POST['keyboard'];
    $mouse = $_POST['mouse'];
    $serialNumber=(int)$_GET['n'];

    $today=date("Y/m/d");
    $newToday=strtotime($today);
    $newPayback=strtotime($pdate);

    if($newToday>$newPayback){
        $status='OFF Warranty';
    }else{
        $status='ON Warranty';
    }

     
    $query="UPDATE `asset` SET `model`='$model',`monitorModel`='$monitorModel',
    `monitorSerial`='$monitorSerial',`computerName`='$computerName',`currentUser`='$currentUser',`ram`='$ram',`hdd`='$hdd',
    `processor`='$processor',`os`='$os',`supplier`='$supplier',`ipaddress`='$ipaddress',`branch`='$branch',
    `mouse`='$mouse',`keyboard`='$keyboard', `status`='$status', `warranty`='$warranty' WHERE serialNumber=$serialNumber";
    $insert_row=$mysqli->query($query) or die($mysqli->error.__LINE__);

        if($insert_row){
            $msg="";
            header('Location:search.php');  
        }else{
            echo "error";
        }
}
