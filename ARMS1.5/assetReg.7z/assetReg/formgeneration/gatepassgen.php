<?php	

$company = $_POST['company'];

$transporterName = $_POST['transporterName'];
$destinationBranch = $_POST['destinationBranch'];
$destination = $_POST['destination'];
$username = $_POST['username'];
$allocationReason = $_POST['allocationReason'];
$department = $_POST['department'];
$company = $_POST['company'];


require ('fpdf17/fpdf.php');

class PDF extends FPDF{
	function Header(){
		$this->SetFont('Arial','B',13);
		
		$path = 'logo.jpg';
		$this->SetXY(100,30);
        $this->Image($path,80,2,50);
		$this->Cell(10,9,'Gate Pass Form',0,1,'C');
			
	}
	
	
	function Footer(){
		$this->Ln();
		$this->SetFont ('Arial','B',10);
		$this->Cell(30,5,'Equipment Released By : .........................................................................................................................',0,1);
		$this->Ln();
		$this->Cell(90,5,'Name: ...........................................................................',0,0);
		$this->Cell(90,5,'Signature : .....................................................................',0,1);
		$this->Ln();
		
		$this->Cell(30,5,'Release Authorized By : ..........................................................................................................................',0,1);
		$this->Ln();
		$this->Cell(90,5,'Name: ...........................................................................',0,0);
		$this->Cell(90,5,'Signature : .....................................................................',0,1);
		$this->Ln();
		
	}

	
function headerTable(){
    $this->Ln();
	$this->Ln();
	

	$this->SetFont('Arial','B',9);
	$this->Cell(20,10,"Item",1,0,'C');
	$this->Cell(70,10,"Description",1,0,'C');
	$this->Cell(100,10,"Seial Number",1,0,'C');
	
	$this->Ln();
}

function viewTable(){

	$this->SetFont('Arial','',9);
	$this->Cell(20,8," ",1,0,'C');
	$this->Cell(70,8," ",1,0,'C');
	$this->Cell(100,8," ",1,0,'C');
	$this->Ln();
	
	$this->Cell(20,8," ",1,0,'C');
	$this->Cell(70,8," ",1,0,'C');
	$this->Cell(100,8," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,8," ",1,0,'C');
	$this->Cell(70,8," ",1,0,'C');
	$this->Cell(100,8," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,8," ",1,0,'C');
	$this->Cell(70,8," ",1,0,'C');
	$this->Cell(100,8," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,8," ",1,0,'C');
	$this->Cell(70,8," ",1,0,'C');
	$this->Cell(100,8," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,8," ",1,0,'C');
	$this->Cell(70,8," ",1,0,'C');
	$this->Cell(100,8," ",1,0,'C');
	$this->Ln();
	
	$this->Cell(20,8," ",1,0,'C');
	$this->Cell(70,8," ",1,0,'C');
	$this->Cell(100,8," ",1,0,'C');
	$this->Ln();
	
	$this->Cell(20,8," ",1,0,'C');
	$this->Cell(70,8," ",1,0,'C');
	$this->Cell(100,8," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,8," ",1,0,'C');
	$this->Cell(70,8," ",1,0,'C');
	$this->Cell(100,8," ",1,0,'C');
	$this->Ln();
	$this->Cell(20,8," ",1,0,'C');
	$this->Cell(70,8," ",1,0,'C');
	$this->Cell(100,8," ",1,0,'C');
	$this->Ln();
	$this->Ln();
	$this->Ln();
	
}



}



$pdf = new PDF('P','mm','A4');
$pdf->AddPage();

$pdf->Image('Watermark.png',20,100,145);


$pdf->SetFont('Arial','B',9);
$pdf->Cell(47,6,"Company :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(47,6,$company,1,0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(47,6,"Username :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(47,6,$username,1,1);

$pdf->SetFont('Arial','B',9);
$pdf->Cell(47,6,"Name Of Transporter :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(47,6,$transporterName,1,0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(47,6,"Destination :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(47,6,$destination,1,1);

$pdf->SetFont('Arial','B',9);
$pdf->Cell(47,6,"Destination Branch :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(47,6,$destinationBranch,1,0);
$pdf->SetFont('Arial','B',9);
$pdf->Cell(47,6,"Department :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(47,6,$department,1,1);

$pdf->SetFont('Arial','B',9);
$pdf->Cell(47,20,"Reason For Transportation :",1,0);
$pdf->SetFont('Arial','',9);
$pdf->Cell(141,20,$allocationReason,1,0);



$pdf->headerTable();
$pdf->viewTable();
$pdf->output();
	
?>